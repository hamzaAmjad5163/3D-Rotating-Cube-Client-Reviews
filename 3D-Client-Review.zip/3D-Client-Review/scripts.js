$(document).ready(function () {
    let rotateX = 0;
    let rotateY = 0;

    $('#next').on('click', function () {
        rotateY += 90; 
        $('.cube').css('transform', `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`);
    });

    $('#prev').on('click', function () {
        rotateY -= 90; 
        $('.cube').css('transform', `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`);
    });
});
